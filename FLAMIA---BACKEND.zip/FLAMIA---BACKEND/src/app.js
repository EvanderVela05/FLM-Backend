import express from "express"


const app = express()

app.use(express.json())

app.get('/', (req, res)=> {
    res.json({mensaje: 'Mi proyecto backend'})
})
//req= petición; res= respuesta

export default app