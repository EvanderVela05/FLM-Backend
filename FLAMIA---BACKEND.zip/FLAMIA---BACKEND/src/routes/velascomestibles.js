import { Router } from "express"
import Velas from '../models/velascomestibles.js'

const router = Router ()

router.get('/', (req, res)=>{
    const velas = Velas.find();
    res.json(velas)
})

router.post('/', (req, res)=>{
    const velas = Velas.create(req.body)
    res.status(201).json(velas)
})

router.put('/', (req, res)=>{
    
})

router.delete('/', (req, res)=>{
    
})
