import mongoose from "mongoose"

const velasSchema = new mongoose.Schema({
    sabor:{
        type:String,
        required: true
    },
    precio:{
        type:Number,
        required: true,
        min: [0, 'Precio mínimo es 0']
    },
    cantidadDisponible:{
        type:Number,
        required: true,
        min: [1, 'Cantidad mínima es de 1']
    }
})

export default mongoose.model('Velas', velasSchema)