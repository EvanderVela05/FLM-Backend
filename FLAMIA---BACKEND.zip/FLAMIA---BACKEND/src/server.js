import app from './app.js'

const PORT = '3000'

app.listen(PORT, console.log('Aplicación en el puerto 3000'))